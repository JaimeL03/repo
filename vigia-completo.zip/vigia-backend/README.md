# Vigía — Backend de monitorización de webs

Backend que conecta tu landing con Uptime Kuma y Stripe para automatizar
el alta de clientes del servicio de monitorización a 3,90€/mes.

## Cómo funciona el flujo completo

1. El cliente rellena el formulario de la landing (`vigia-landing.html`) → llama a `POST /signup`
2. El backend crea un Customer en Stripe y le devuelve la URL de Stripe Checkout
3. El cliente paga en Stripe
4. Stripe avisa al backend vía webhook (`POST /webhooks/stripe`)
5. El backend crea automáticamente un monitor en Uptime Kuma para esa web
6. Cuando Kuma detecta que la web cae o se recupera, llama a `POST /webhooks/kuma`
7. El backend envía el email correspondiente vía Resend, con la plantilla de marca

## Pasos para desplegar en tu servidor (Ubuntu Server)

### 1. Requisitos previos en tu servidor
```bash
# Si no tienes Docker instalado:
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# cierra sesión y vuelve a entrar para que el grupo surta efecto
```

### 2. Copia este proyecto a tu servidor
Sube esta carpeta completa (`vigia-backend/`) a tu servidor, por ejemplo vía `scp` o `git`.

### 3. Configura las variables de entorno
```bash
cp .env.example .env
nano .env
```
Rellena cada valor real:
- `KUMA_PASSWORD`: pon una contraseña fuerte, la usarás también al crear el admin de Kuma en el paso 5
- `STRIPE_SECRET_KEY`: la encuentras en https://dashboard.stripe.com/apikeys
- `STRIPE_PRICE_ID`: créalo en Stripe → Product catalog → crea un producto "Vigía" con precio recurrente de 3,90€/mes, copia el ID del Price (empieza por `price_`)
- `STRIPE_WEBHOOK_SECRET`: lo obtienes en el paso 7
- `RESEND_API_KEY`: créate una cuenta gratis en https://resend.com y genera una API key
- `ALERT_FROM_EMAIL`: tiene que ser un email de un dominio que verifiques en Resend (Resend te guía en esto)
- `BACKEND_PUBLIC_URL`: la URL pública por la que Kuma podrá llamar a tu backend (ver paso 6, normalmente algo como `https://api.tudominio.es`)

### 4. Levanta los contenedores
```bash
docker compose up -d --build
```
Esto levanta Uptime Kuma (puerto 3001, solo accesible en localhost) y tu backend (puerto 8000, solo accesible en localhost).

### 5. Configura Uptime Kuma por primera vez
Como Kuma solo escucha en `127.0.0.1`, necesitas un túnel SSH temporal para acceder desde tu ordenador la primera vez:
```bash
ssh -L 3001:localhost:3001 tu_usuario@tu_servidor
```
Abre `http://localhost:3001` en tu navegador y crea el usuario admin con el mismo usuario/contraseña que pusiste en `KUMA_PASSWORD` del `.env`.

### 6. Expón backend y Kuma a internet con Cloudflare Tunnel
Esto evita abrir puertos en tu router. Instala `cloudflared` y crea dos rutas:
- `api.tudominio.es` → `http://localhost:8000` (tu backend, para que Stripe y Kuma le hablen)
- `panel.tudominio.es` → `http://localhost:3001` (el panel de Kuma, solo para ti — considera protegerlo además con Cloudflare Access)

Guía oficial: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/

### 7. Configura el webhook de Stripe
En tu dashboard de Stripe → Developers → Webhooks → Add endpoint:
- URL: `https://api.tudominio.es/webhooks/stripe`
- Eventos a escuchar: `checkout.session.completed` y `customer.subscription.deleted`
- Copia el "Signing secret" que te da Stripe y pégalo en `STRIPE_WEBHOOK_SECRET` de tu `.env`
- Reinicia el backend: `docker compose restart vigia-backend`

### 8. Conecta la landing al backend
En `vigia-landing.html`, el formulario actualmente solo simula el envío.
Hay que cambiar el JavaScript del submit para que llame a tu API real:

```javascript
document.getElementById('signupForm').addEventListener('submit', async function(e){
  e.preventDefault();
  const response = await fetch('https://api.tudominio.es/signup', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      email: document.getElementById('email').value,
      website_url: document.getElementById('webUrl').value,
      notify_channel: 'email'
    })
  });
  const data = await response.json();
  window.location.href = data.checkout_url; // redirige a Stripe Checkout
});
```

### 9. Prueba el flujo completo
Usa una tarjeta de prueba de Stripe (`4242 4242 4242 4242`, cualquier fecha futura y CVC)
con `STRIPE_SECRET_KEY` en modo test antes de pasar a producción.

## Notas importantes

- El payload exacto que envía Kuma en sus notificaciones webhook puede variar
  ligeramente entre versiones. Si `kuma_webhook_routes.py` no detecta bien el
  estado, revisa los logs (`docker compose logs vigia-backend`) la primera vez
  que se dispare una alerta real para ajustar el parseo del payload si hace falta.
- Los límites de memoria en `docker-compose.yml` (512MB Kuma + 256MB backend)
  son conservadores; con tus 12GB totales tienes margen de sobra incluso con
  tus otros bots corriendo a la vez.
- Cuando quieras añadir Telegram o SMS como canal de aviso, el campo
  `notify_channel` ya existe en la base de datos y en el formulario — solo
  falta añadir la lógica correspondiente en `email_service.py` (o un nuevo
  servicio `telegram_service.py`) y activarlo en el HTML de la landing.

## Plan Plus (alertas de reseñas de Google) — flujo de prepago condicionado

El plan Plus (7€/mes) añade alertas cuando llega una reseña negativa en
Google, con una respuesta sugerida. A diferencia del plan Básico, el cobro
**no es inmediato**: como la API de Business Profile necesita aprobación de
Google (puede tardar semanas), el cliente se da de alta y guarda su método
de pago, pero no se le cobra nada hasta que tú activas el servicio a mano.

### Flujo completo

1. Cliente rellena el formulario eligiendo plan Plus → `POST /signup-plus`
2. El backend crea un Customer en Stripe y un `SetupIntent` (guarda la
   tarjeta sin cobrar) — el cliente confirma su tarjeta en el frontend con
   Stripe.js usando el `setup_client_secret` que devuelve el endpoint
3. El cliente conecta su cuenta de Google (OAuth) desde la misma landing
4. Mientras tanto, tú solicitas acceso a la Business Profile Reviews API en
   Google Cloud Console (esto se hace una sola vez para todo el negocio,
   no por cliente) y construyes la lógica de lectura periódica de reseñas
5. Cuando la API esté aprobada, consulta `GET /admin/pending-plus-clients`
   (con tu `ADMIN_SECRET` en el header `X-Admin-Secret`) para ver quién ya
   conectó Google y está esperando
6. Para cada cliente, llama a `POST /admin/activate-plus/{client_id}` — esto
   crea la suscripción real en Stripe (empieza el cobro de 7€/mes) y le
   manda automáticamente el email de "tu plan Plus ya está activo"

### Pendiente de implementar (no incluido todavía en este código)

- El intercambio real del código de OAuth de Google por un token de acceso
  (ahora mismo `signup_plus` solo guarda el código tal cual como placeholder)
- El job periódico que consulta la Reviews API de cada cliente activo y
  llama a `email_service.send_negative_review_alert(...)` cuando detecta
  una reseña nueva de pocas estrellas
- Generar la "respuesta sugerida" del email de alerta (buen candidato para
  usar la API de Claude: le pasas el texto de la reseña y el nombre del
  negocio, y te devuelve un borrador de respuesta profesional)
- Un panel de administración real en vez de los endpoints `/admin/*`
  protegidos solo por un secreto compartido
