"""
Envío de emails de alerta vía Resend, con el mismo lenguaje visual que la landing:
directo, claro, sin tecnicismos. Esto reemplaza el email genérico de Uptime Kuma.
"""
import os
import resend
from datetime import datetime

resend.api_key = os.environ["RESEND_API_KEY"]
FROM_EMAIL = os.environ["ALERT_FROM_EMAIL"]


def _html_template(website_url: str, status: str, since: str) -> str:
    if status == "down":
        subject_emoji = "⚠️"
        title = f"{website_url} no responde"
        message = (
            f"Hemos detectado que <b>{website_url}</b> dejó de responder a las {since}.<br><br>"
            "Te avisamos para que puedas revisarlo cuanto antes."
        )
        accent = "#FF6B5B"
        bg = "#FFF1EF"
    else:
        subject_emoji = "✅"
        title = f"{website_url} ha vuelto"
        message = (
            f"Buenas noticias: <b>{website_url}</b> ha vuelto a responder con normalidad.<br><br>"
            "Seguimos vigilando como siempre."
        )
        accent = "#1F4D3D"
        bg = "#EAF3EE"

    return f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">{subject_emoji} {title}</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Vigía</div>
        <div style="background:{bg}; border-left:4px solid {accent}; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17;">
          {message}
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Hecho para que tu negocio nunca esté a oscuras.
      </div>
    </div>
    """


def send_down_alert(to_email: str, website_url: str):
    since = datetime.now().strftime("%H:%M")
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"⚠️ {website_url} no responde",
        "html": _html_template(website_url, "down", since),
    })


def send_recovery_alert(to_email: str, website_url: str):
    since = datetime.now().strftime("%H:%M")
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"✅ {website_url} ha vuelto",
        "html": _html_template(website_url, "up", since),
    })
