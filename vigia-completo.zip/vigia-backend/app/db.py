"""
Base de datos local muy sencilla (SQLite) que guarda la relación entre:
- el cliente (email, stripe_customer_id, stripe_subscription_id)
- su monitor en Uptime Kuma (kuma_monitor_id)

Uptime Kuma no sabe nada de Stripe ni de "clientes", solo de monitores.
Esta tabla es el pegamento entre ambos mundos.
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "data" / "vigia.db"
DB_PATH.parent.mkdir(exist_ok=True)


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                website_url TEXT NOT NULL,
                notify_channel TEXT NOT NULL DEFAULT 'email',
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT UNIQUE,
                kuma_monitor_id INTEGER,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def create_pending_client(email: str, website_url: str, notify_channel: str, stripe_customer_id: str) -> int:
    with get_db() as db:
        cur = db.execute(
            "INSERT INTO clients (email, website_url, notify_channel, stripe_customer_id, status) "
            "VALUES (?, ?, ?, ?, 'pending')",
            (email, website_url, notify_channel, stripe_customer_id),
        )
        db.commit()
        return cur.lastrowid


def activate_client(stripe_subscription_id: str, stripe_customer_id: str, kuma_monitor_id: int):
    with get_db() as db:
        db.execute(
            "UPDATE clients SET status = 'active', stripe_subscription_id = ?, kuma_monitor_id = ? "
            "WHERE stripe_customer_id = ? AND status = 'pending'",
            (stripe_subscription_id, kuma_monitor_id, stripe_customer_id),
        )
        db.commit()


def get_client_by_subscription(stripe_subscription_id: str):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE stripe_subscription_id = ?",
            (stripe_subscription_id,),
        ).fetchone()
        return dict(row) if row else None


def get_client_by_monitor_id(kuma_monitor_id: int):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE kuma_monitor_id = ?",
            (kuma_monitor_id,),
        ).fetchone()
        return dict(row) if row else None


def get_pending_client_by_customer(stripe_customer_id: str):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE stripe_customer_id = ? AND status = 'pending' "
            "ORDER BY id DESC LIMIT 1",
            (stripe_customer_id,),
        ).fetchone()
        return dict(row) if row else None


def deactivate_client(stripe_subscription_id: str):
    with get_db() as db:
        db.execute(
            "UPDATE clients SET status = 'cancelled' WHERE stripe_subscription_id = ?",
            (stripe_subscription_id,),
        )
        db.commit()
