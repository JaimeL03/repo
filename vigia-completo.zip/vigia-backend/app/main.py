from dotenv import load_dotenv
load_dotenv()  # carga el .env ANTES de que se importen los módulos que leen os.environ

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import db
from app.routes import stripe_routes, kuma_webhook_routes

app = FastAPI(title="Vigía Backend")

# En producción, restringe esto a tu dominio real en vez de "*"
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

db.init_db()

app.include_router(stripe_routes.router)
app.include_router(kuma_webhook_routes.router)


@app.get("/health")
def health():
    return {"status": "ok"}
