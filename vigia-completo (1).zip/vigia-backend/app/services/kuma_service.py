"""
Capa de integración con Uptime Kuma.

Importante: uptime-kuma-api se conecta vía socket.io y cada llamada
abre/cierra conexión. Para nuestro volumen (altas/bajas puntuales, no
miles por segundo) esto es totalmente correcto y simple.
"""
import os
from uptime_kuma_api import UptimeKumaApi, MonitorType

KUMA_URL = os.environ["KUMA_URL"]
KUMA_USERNAME = os.environ["KUMA_USERNAME"]
KUMA_PASSWORD = os.environ["KUMA_PASSWORD"]
KUMA_WEBHOOK_SECRET = os.environ["KUMA_WEBHOOK_SECRET"]
BACKEND_PUBLIC_URL = os.environ.get("BACKEND_PUBLIC_URL", "http://vigia-backend:8000")


def _get_or_create_webhook_notification(api: UptimeKumaApi) -> int:
    """
    Busca si ya existe una notificación tipo webhook apuntando a nuestro propio
    backend. Si no existe, la crea. Esto evita crear una notificación duplicada
    cada vez que entra un cliente nuevo.
    """
    from uptime_kuma_api import NotificationType

    existing = api.get_notifications()
    for n in existing:
        if n["name"] == "vigia-internal-webhook":
            return n["id"]

    webhook_url = f"{BACKEND_PUBLIC_URL}/webhooks/kuma?secret={KUMA_WEBHOOK_SECRET}"
    result = api.add_notification(
        name="vigia-internal-webhook",
        type=NotificationType.WEBHOOK,
        isDefault=False,
        applyExisting=False,
        webhookUrl=webhook_url,
        webhookContentType="json",
    )
    return result["monitorID"] if "monitorID" in result else result.get("id")


def create_monitor_for_client(website_url: str, friendly_name: str) -> int:
    """
    Crea un monitor HTTP en Kuma para la web del cliente, comprobando cada
    3 minutos (180s), y enganchado a nuestra notificación webhook propia.
    Devuelve el ID del monitor creado.
    """
    with UptimeKumaApi(KUMA_URL) as api:
        api.login(KUMA_USERNAME, KUMA_PASSWORD)
        notification_id = _get_or_create_webhook_notification(api)

        result = api.add_monitor(
            type=MonitorType.HTTP,
            name=friendly_name,
            url=website_url,
            interval=180,          # comprobación cada 3 minutos
            retryInterval=60,      # si falla, reintenta cada 60s
            maxretries=2,          # solo avisa tras 2 reintentos fallidos (evita falsos positivos puntuales)
            notificationIDList=[notification_id] if notification_id else [],
        )
        monitor_id = result.get("monitorID") or result.get("monitorId")
        return monitor_id


def pause_monitor(monitor_id: int):
    with UptimeKumaApi(KUMA_URL) as api:
        api.login(KUMA_USERNAME, KUMA_PASSWORD)
        api.pause_monitor(monitor_id)


def delete_monitor(monitor_id: int):
    with UptimeKumaApi(KUMA_URL) as api:
        api.login(KUMA_USERNAME, KUMA_PASSWORD)
        api.delete_monitor(monitor_id)
