"""
Envío de emails de alerta vía Resend, con el mismo lenguaje visual que la landing:
directo, claro, sin tecnicismos. Esto reemplaza el email genérico de Uptime Kuma.
"""
import os
import resend
from datetime import datetime

resend.api_key = os.environ["RESEND_API_KEY"]
FROM_EMAIL = os.environ["ALERT_FROM_EMAIL"]


def _html_template(website_url: str, status: str, since: str) -> str:
    if status == "down":
        subject_emoji = "⚠️"
        title = f"{website_url} no responde"
        message = (
            f"Hemos detectado que <b>{website_url}</b> dejó de responder a las {since}.<br><br>"
            "Te avisamos para que puedas revisarlo cuanto antes."
        )
        accent = "#FF6B5B"
        bg = "#FFF1EF"
    else:
        subject_emoji = "✅"
        title = f"{website_url} ha vuelto"
        message = (
            f"Buenas noticias: <b>{website_url}</b> ha vuelto a responder con normalidad.<br><br>"
            "Seguimos vigilando como siempre."
        )
        accent = "#1F4D3D"
        bg = "#EAF3EE"

    return f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">{subject_emoji} {title}</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Vigía</div>
        <div style="background:{bg}; border-left:4px solid {accent}; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17;">
          {message}
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Hecho para que tu negocio nunca esté a oscuras.
      </div>
    </div>
    """


def send_down_alert(to_email: str, website_url: str):
    since = datetime.now().strftime("%H:%M")
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"⚠️ {website_url} no responde",
        "html": _html_template(website_url, "down", since),
    })


def send_welcome_email(to_email: str, website_url: str, plan: str = "basico"):
    """
    Email de bienvenida nada más completar el alta del plan Básico (cobro
    inmediato ya confirmado por Stripe). Da una primera impresión de
    producto cuidado y confirma los datos que el cliente introdujo, para
    que pueda detectar enseguida si algo está mal (ej. una URL mal escrita).
    """
    html = f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">👋 ¡Bienvenido a Vigía!</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Tu web ya está bajo vigilancia</div>
        <div style="background:#EAF3EE; border-left:4px solid #1F4D3D; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17;">
          Desde ahora comprobamos <b>{website_url}</b> cada 3 minutos.<br><br>
          Si en algún momento deja de responder, te avisaremos aquí mismo, al instante. No tienes que hacer nada más — simplemente sigue con tu negocio tranquilo.
        </div>
        <div style="margin-top:18px; font-size:13px; color:rgba(28,27,23,0.55);">
          ¿La URL no es correcta o quieres cambiar algo? Responde a este correo y te ayudamos.
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Hecho para que tu negocio nunca esté a oscuras.
      </div>
    </div>
    """
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": "👋 Bienvenido a Vigía — tu web ya está vigilada",
        "html": html,
    })


def send_value_reminder_email(to_email: str, website_url: str, uptime_percentage: float, days_period: int = 60):
    """
    Recordatorio periódico de valor demostrado. Pensado para clientes que
    llevan un tiempo sin recibir ninguna alerta de caída -- no porque el
    servicio no funcione, sino porque su web no se ha caído. Sin este
    recordatorio, esos clientes no tienen ninguna señal de que están
    pagando por algo que realmente está trabajando para ellos.

    uptime_percentage: porcentaje de tiempo online en el periodo, ej. 99.98
    """
    html = f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">📊 Resumen de tu web</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Últimos {days_period} días</div>
        <div style="background:#EAF3EE; border-left:4px solid #1F4D3D; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17;">
          <b>{website_url}</b> ha estado online el <b>{uptime_percentage}%</b> del tiempo.<br><br>
          Seguimos vigilando cada 3 minutos, así que en cuanto algo cambie, lo sabrás antes que tus clientes.
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Hecho para que tu negocio nunca esté a oscuras.
      </div>
    </div>
    """
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"📊 Tu web ha estado online el {uptime_percentage}% este periodo",
        "html": html,
    })


def send_recovery_alert(to_email: str, website_url: str):
    since = datetime.now().strftime("%H:%M")
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"✅ {website_url} ha vuelto",
        "html": _html_template(website_url, "up", since),
    })


def send_plus_activated_email(to_email: str, business_name: str):
    """
    Email que se manda cuando el plan Plus de un cliente pasa de 'pendiente'
    a 'activo de verdad' -- es decir, cuando ya tenemos acceso aprobado a la
    API de Google Y ese cliente ha completado su OAuth. A partir de este
    momento empieza también el cobro real de los 7€/mes (la suscripción de
    Stripe se activa en el mismo paso, ver stripe_routes.py).
    """
    html = f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">✅ Tu plan Plus ya está activo</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Vigía</div>
        <div style="background:#EAF3EE; border-left:4px solid #1F4D3D; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17;">
          Ya estamos vigilando las reseñas de Google de <b>{business_name}</b>.<br><br>
          A partir de ahora, si te llega una reseña negativa te avisaremos aquí mismo, junto con una propuesta de respuesta para que puedas contestar rápido.<br><br>
          A partir de hoy se activa también la cuota mensual de 7€ del plan Plus.
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Hecho para que tu negocio nunca esté a oscuras.
      </div>
    </div>
    """
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": "✅ Tu plan Plus de Vigía ya está activo",
        "html": html,
    })


def send_negative_review_alert(to_email: str, business_name: str, review_text: str, review_rating: int, suggested_reply: str):
    """
    El email principal del plan Plus: se dispara cuando se detecta una
    reseña nueva de 1-3 estrellas en el perfil de Google del cliente.
    """
    stars = "⭐" * review_rating
    html = f"""
    <div style="font-family: -apple-system, Inter, sans-serif; max-width: 480px; margin: 0 auto; background:#FAF6EE; padding: 32px;">
      <div style="background:#fff; border-radius:16px; padding: 28px; border:1px solid rgba(28,27,23,0.1);">
        <div style="font-weight:700; font-size:18px; margin-bottom:4px;">⚠️ Nueva reseña en {business_name}</div>
        <div style="font-size:13px; color:rgba(28,27,23,0.5); margin-bottom:18px;">Vigía Plus</div>
        <div style="background:#FFF1EF; border-left:4px solid #FF6B5B; border-radius:8px; padding:16px; font-size:15px; line-height:1.6; color:#1C1B17; margin-bottom:18px;">
          <div style="margin-bottom:6px;">{stars}</div>
          "{review_text}"
        </div>
        <div style="font-size:13px; font-weight:600; color:rgba(28,27,23,0.6); margin-bottom:6px;">RESPUESTA SUGERIDA</div>
        <div style="background:#F1EADA; border-radius:8px; padding:16px; font-size:14px; line-height:1.6; color:#1C1B17;">
          {suggested_reply}
        </div>
      </div>
      <div style="text-align:center; font-size:12px; color:rgba(28,27,23,0.4); margin-top:16px;">
        Puedes usar esta respuesta tal cual, o ajustarla antes de publicarla en Google.
      </div>
    </div>
    """
    resend.Emails.send({
        "from": FROM_EMAIL,
        "to": to_email,
        "subject": f"⚠️ Nueva reseña en {business_name}",
        "html": html,
    })
