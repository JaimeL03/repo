"""
Base de datos local muy sencilla (SQLite) que guarda la relación entre:
- el cliente (email, stripe_customer_id, stripe_subscription_id)
- su monitor en Uptime Kuma (kuma_monitor_id)

Uptime Kuma no sabe nada de Stripe ni de "clientes", solo de monitores.
Esta tabla es el pegamento entre ambos mundos.
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "data" / "vigia.db"
DB_PATH.parent.mkdir(exist_ok=True)


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                website_url TEXT NOT NULL,
                notify_channel TEXT NOT NULL DEFAULT 'email',
                plan TEXT NOT NULL DEFAULT 'basico',
                business_name TEXT,
                google_oauth_token TEXT,
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT UNIQUE,
                stripe_setup_intent_id TEXT,
                kuma_monitor_id INTEGER,
                reviews_active INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def create_pending_client(email: str, website_url: str, notify_channel: str, stripe_customer_id: str) -> int:
    with get_db() as db:
        cur = db.execute(
            "INSERT INTO clients (email, website_url, notify_channel, stripe_customer_id, status) "
            "VALUES (?, ?, ?, ?, 'pending')",
            (email, website_url, notify_channel, stripe_customer_id),
        )
        db.commit()
        return cur.lastrowid


def activate_client(stripe_subscription_id: str, stripe_customer_id: str, kuma_monitor_id: int):
    with get_db() as db:
        db.execute(
            "UPDATE clients SET status = 'active', stripe_subscription_id = ?, kuma_monitor_id = ? "
            "WHERE stripe_customer_id = ? AND status = 'pending'",
            (stripe_subscription_id, kuma_monitor_id, stripe_customer_id),
        )
        db.commit()


def get_client_by_subscription(stripe_subscription_id: str):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE stripe_subscription_id = ?",
            (stripe_subscription_id,),
        ).fetchone()
        return dict(row) if row else None


def get_client_by_monitor_id(kuma_monitor_id: int):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE kuma_monitor_id = ?",
            (kuma_monitor_id,),
        ).fetchone()
        return dict(row) if row else None


def get_pending_client_by_customer(stripe_customer_id: str):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM clients WHERE stripe_customer_id = ? AND status = 'pending' "
            "ORDER BY id DESC LIMIT 1",
            (stripe_customer_id,),
        ).fetchone()
        return dict(row) if row else None


def deactivate_client(stripe_subscription_id: str):
    with get_db() as db:
        db.execute(
            "UPDATE clients SET status = 'cancelled' WHERE stripe_subscription_id = ?",
            (stripe_subscription_id,),
        )
        db.commit()


def create_pending_plus_client(email: str, website_url: str, business_name: str, stripe_customer_id: str, stripe_setup_intent_id: str):
    """
    Alta de un cliente del plan Plus. A diferencia del plan Básico, aquí NO
    se crea ninguna suscripción de cobro todavía -- solo se guarda el método
    de pago vía SetupIntent. La suscripción real se crea más adelante, a
    mano por el dueño del negocio, cuando el servicio esté listo para ese
    cliente (ver activate_plus_client más abajo).
    """
    with get_db() as db:
        cur = db.execute(
            "INSERT INTO clients (email, website_url, business_name, plan, stripe_customer_id, "
            "stripe_setup_intent_id, status) VALUES (?, ?, ?, 'plus', ?, ?, 'plus_pending')",
            (email, website_url, business_name, stripe_customer_id, stripe_setup_intent_id),
        )
        db.commit()
        return cur.lastrowid


def save_google_oauth_token(client_id: int, oauth_token: str):
    with get_db() as db:
        db.execute(
            "UPDATE clients SET google_oauth_token = ? WHERE id = ?",
            (oauth_token, client_id),
        )
        db.commit()


def get_pending_plus_clients():
    """Clientes Plus que ya conectaron Google pero aún no tienen el servicio activo de verdad."""
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM clients WHERE plan = 'plus' AND status = 'plus_pending' "
            "AND google_oauth_token IS NOT NULL"
        ).fetchall()
        return [dict(r) for r in rows]


def activate_plus_client(client_id: int, stripe_subscription_id: str):
    """
    Se llama cuando TÚ decides activar de verdad el servicio para un cliente
    concreto (una vez la API de Google está aprobada). A partir de aquí
    empieza el cobro real -- la suscripción de Stripe se crea en ese mismo
    momento, no antes.
    """
    with get_db() as db:
        db.execute(
            "UPDATE clients SET status = 'active', reviews_active = 1, "
            "stripe_subscription_id = ? WHERE id = ?",
            (stripe_subscription_id, client_id),
        )
        db.commit()


def get_client_by_id(client_id: int):
    with get_db() as db:
        row = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
        return dict(row) if row else None
