"""
Script para mandar el recordatorio periódico de "tu web ha estado online
el X% del tiempo" a todos los clientes activos. Pensado para ejecutarse
una vez al mes (por ejemplo vía cron en el servidor), no como parte del
flujo en tiempo real del backend principal.

Uso:
    python -m app.jobs.send_value_reminders

Cron sugerido (primer día de cada mes a las 9:00):
    0 9 1 * * cd /ruta/al/proyecto && python -m app.jobs.send_value_reminders
"""
import os
import sys

# Permite ejecutar este archivo como script suelto sin problemas de import
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from dotenv import load_dotenv
load_dotenv()

from app import db
from app.services import kuma_service, email_service

DAYS_PERIOD = 60  # ventana de tiempo que se reporta en el email
HOURS_PERIOD = DAYS_PERIOD * 24


def calculate_uptime_percentage(monitor_id: int) -> float:
    """
    Calcula el % de tiempo online a partir de los heartbeats de Kuma.
    Si no hay datos suficientes (cliente muy reciente), devuelve None
    para que el job sepa que debe omitirlo en vez de mandar un dato falso.
    """
    from uptime_kuma_api import UptimeKumaApi

    KUMA_URL = os.environ["KUMA_URL"]
    KUMA_USERNAME = os.environ["KUMA_USERNAME"]
    KUMA_PASSWORD = os.environ["KUMA_PASSWORD"]

    with UptimeKumaApi(KUMA_URL) as api:
        api.login(KUMA_USERNAME, KUMA_PASSWORD)
        beats = api.get_monitor_beats(monitor_id, HOURS_PERIOD)

    if not beats:
        return None

    # Cada beat representa un intervalo de comprobación; status 1 = up, 0 = down.
    # No es una medida de tiempo perfectamente exacta (los intervalos pueden
    # variar ligeramente), pero es una aproximación más que suficiente para
    # un email de "valor demostrado", no para un SLA contractual.
    up_count = sum(1 for b in beats if b["status"] == 1)
    return round((up_count / len(beats)) * 100, 2)


def run():
    with db.get_db() as conn:
        clients = conn.execute(
            "SELECT * FROM clients WHERE status = 'active' AND kuma_monitor_id IS NOT NULL"
        ).fetchall()

    print(f"Procesando {len(clients)} clientes activos...")

    for client in clients:
        client = dict(client)
        uptime_pct = calculate_uptime_percentage(client["kuma_monitor_id"])

        if uptime_pct is None:
            print(f"  - {client['website_url']}: sin datos suficientes todavía, omitido")
            continue

        email_service.send_value_reminder_email(
            to_email=client["email"],
            website_url=client["website_url"],
            uptime_percentage=uptime_pct,
            days_period=DAYS_PERIOD,
        )
        print(f"  - {client['website_url']}: {uptime_pct}% — email enviado")

    print("Listo.")


if __name__ == "__main__":
    run()
