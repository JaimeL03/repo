import os
from fastapi import APIRouter, Request, HTTPException

from app import db
from app.services import email_service

router = APIRouter()

KUMA_WEBHOOK_SECRET = os.environ["KUMA_WEBHOOK_SECRET"]


@router.post("/webhooks/kuma")
async def kuma_webhook(request: Request, secret: str):
    """
    Uptime Kuma llama aquí cuando un monitor cambia de estado (up/down).
    Validamos el secreto compartido por query param para asegurarnos de
    que la llamada viene de nuestro propio Kuma y no de un tercero que
    haya descubierto la URL.

    Formato del payload de Kuma (notificación tipo webhook):
    https://github.com/louislam/uptime-kuma/wiki -> consultar el payload
    exacto en tu versión instalada, puede variar levemente entre releases.
    """
    if secret != KUMA_WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Secreto inválido")

    payload = await request.json()

    monitor_id = payload.get("monitor", {}).get("id")
    heartbeat = payload.get("heartbeat", {})
    status = heartbeat.get("status")  # 1 = up, 0 = down en Kuma

    if monitor_id is None or status is None:
        # Payload inesperado: lo ignoramos en vez de fallar, para no tirar
        # el endpoint si Kuma cambia el formato en una actualización futura.
        return {"ignored": True}

    client = db.get_client_by_monitor_id(monitor_id)
    if not client:
        return {"ignored": True, "reason": "monitor sin cliente asociado"}

    if client["notify_channel"] == "email":
        if status == 0:
            email_service.send_down_alert(client["email"], client["website_url"])
        elif status == 1:
            email_service.send_recovery_alert(client["email"], client["website_url"])

    return {"processed": True}
