import os
import stripe
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, EmailStr, HttpUrl
from typing import Optional

from app import db
from app.services import email_service

router = APIRouter()

stripe.api_key = os.environ["STRIPE_SECRET_KEY"]
STRIPE_PRICE_ID_PLUS = os.environ["STRIPE_PRICE_ID_PLUS"]
# Secreto simple para proteger el endpoint de activación manual.
# No es un sistema de login completo -- es solo para que tú (el dueño del
# negocio) puedas activar clientes a mano desde un script o Postman, sin
# montar un panel de administración completo todavía.
ADMIN_SECRET = os.environ["ADMIN_SECRET"]


class PlusSignupRequest(BaseModel):
    email: EmailStr
    website_url: HttpUrl
    business_name: str
    google_oauth_code: Optional[str] = None  # código de autorización que devuelve Google tras el OAuth


@router.post("/signup-plus")
def signup_plus(payload: PlusSignupRequest):
    """
    Alta del plan Plus. Importante: aquí NO se cobra nada todavía.
    Se crea un Customer en Stripe y se usa un SetupIntent para guardar el
    método de pago de forma segura, sin crear ninguna suscripción activa.
    """
    customer = stripe.Customer.create(email=payload.email)

    setup_intent = stripe.SetupIntent.create(
        customer=customer.id,
        payment_method_types=["card"],
    )

    client_id = db.create_pending_plus_client(
        email=payload.email,
        website_url=str(payload.website_url),
        business_name=payload.business_name,
        stripe_customer_id=customer.id,
        stripe_setup_intent_id=setup_intent.id,
    )

    if payload.google_oauth_code:
        # TODO: aquí va el intercambio real del código de autorización por un
        # token de acceso/refresco de Google (flujo OAuth estándar). De
        # momento se guarda el código tal cual como placeholder.
        db.save_google_oauth_token(client_id, payload.google_oauth_code)

    return {
        "client_id": client_id,
        # El frontend usa esto para completar la confirmación de la tarjeta
        # con Stripe.js, sin que el backend vea nunca el número de tarjeta.
        "setup_client_secret": setup_intent.client_secret,
    }


@router.get("/admin/pending-plus-clients")
def list_pending_plus_clients(x_admin_secret: str = Header(...)):
    """Lista clientes Plus que ya conectaron Google y están esperando activación."""
    if x_admin_secret != ADMIN_SECRET:
        raise HTTPException(status_code=403, detail="No autorizado")
    return db.get_pending_plus_clients()


@router.post("/admin/activate-plus/{client_id}")
def activate_plus_client(client_id: int, x_admin_secret: str = Header(...)):
    """
    Activa de verdad el servicio para un cliente Plus concreto: crea la
    suscripción real en Stripe (a partir de aquí empieza el cobro de 7€/mes)
    y le manda el email de "tu servicio ya está activo".

    Llamar a esto solo cuando: 1) la API de Business Profile esté aprobada
    para tu proyecto, y 2) este cliente ya haya completado su OAuth.
    """
    if x_admin_secret != ADMIN_SECRET:
        raise HTTPException(status_code=403, detail="No autorizado")

    client = db.get_client_by_id(client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    if not client["google_oauth_token"]:
        raise HTTPException(status_code=400, detail="Este cliente aún no ha conectado Google")

    # Confirma el SetupIntent en una suscripción real: usa el método de pago
    # ya guardado para crear la suscripción de cobro recurrente de 7€/mes.
    setup_intent = stripe.SetupIntent.retrieve(client["stripe_setup_intent_id"])
    payment_method_id = setup_intent.payment_method

    stripe.PaymentMethod.attach(payment_method_id, customer=client["stripe_customer_id"])
    stripe.Customer.modify(
        client["stripe_customer_id"],
        invoice_settings={"default_payment_method": payment_method_id},
    )

    subscription = stripe.Subscription.create(
        customer=client["stripe_customer_id"],
        items=[{"price": STRIPE_PRICE_ID_PLUS}],
    )

    db.activate_plus_client(client_id, subscription.id)
    email_service.send_plus_activated_email(client["email"], client["business_name"])

    return {"activated": True, "subscription_id": subscription.id}
