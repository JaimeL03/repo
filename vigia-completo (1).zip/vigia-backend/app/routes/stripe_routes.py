import os
import stripe
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, EmailStr, HttpUrl

from app import db
from app.services import kuma_service, email_service

router = APIRouter()

stripe.api_key = os.environ["STRIPE_SECRET_KEY"]
STRIPE_WEBHOOK_SECRET = os.environ["STRIPE_WEBHOOK_SECRET"]
STRIPE_PRICE_ID = os.environ["STRIPE_PRICE_ID"]
FRONTEND_SUCCESS_URL = os.environ["FRONTEND_SUCCESS_URL"]
FRONTEND_CANCEL_URL = os.environ["FRONTEND_CANCEL_URL"]


class SignupRequest(BaseModel):
    email: EmailStr
    website_url: HttpUrl
    notify_channel: str = "email"  # de momento solo "email" está activo


@router.post("/signup")
def signup(payload: SignupRequest):
    """
    Paso 1 del alta: el cliente rellena el formulario de la landing.
    Creamos un Customer en Stripe, guardamos el alta como 'pending' en
    nuestra BD, y devolvemos la URL de Stripe Checkout para que pague.
    El monitor de Kuma NO se crea aquí todavía -- se crea solo cuando
    Stripe confirma que el pago se ha completado (ver webhook más abajo).
    """
    customer = stripe.Customer.create(email=payload.email)

    db.create_pending_client(
        email=payload.email,
        website_url=str(payload.website_url),
        notify_channel=payload.notify_channel,
        stripe_customer_id=customer.id,
    )

    checkout_session = stripe.checkout.Session.create(
        customer=customer.id,
        mode="subscription",
        line_items=[{"price": STRIPE_PRICE_ID, "quantity": 1}],
        success_url=FRONTEND_SUCCESS_URL,
        cancel_url=FRONTEND_CANCEL_URL,
    )

    return {"checkout_url": checkout_session.url}


@router.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    """
    Stripe nos avisa aquí de eventos de pago. Los dos que nos importan:
    - checkout.session.completed -> el cliente pagó por primera vez, creamos su monitor
    - customer.subscription.deleted -> el cliente canceló, pausamos/borramos su monitor
    """
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except (ValueError, stripe.error.SignatureVerificationError):
        raise HTTPException(status_code=400, detail="Firma de Stripe inválida")

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        customer_id = session["customer"]
        subscription_id = session["subscription"]

        pending = db.get_pending_client_by_customer(customer_id)
        if pending:
            monitor_id = kuma_service.create_monitor_for_client(
                website_url=pending["website_url"],
                friendly_name=pending["website_url"],
            )
            db.activate_client(
                stripe_subscription_id=subscription_id,
                stripe_customer_id=customer_id,
                kuma_monitor_id=monitor_id,
            )
            email_service.send_welcome_email(
                to_email=pending["email"],
                website_url=pending["website_url"],
            )

    elif event["type"] == "customer.subscription.deleted":
        subscription = event["data"]["object"]
        client = db.get_client_by_subscription(subscription["id"])
        if client and client["kuma_monitor_id"]:
            kuma_service.delete_monitor(client["kuma_monitor_id"])
            db.deactivate_client(subscription["id"])

    return {"received": True}
